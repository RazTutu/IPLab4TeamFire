import java.util.Vector;

public class AdmisionComitee {

  public AdmisionMember membri;

    /**
   * 
   * @element-type AdmisionMember
   */
  public Vector  myAdmisionMember;
    public Vector  myAplicatie;

}