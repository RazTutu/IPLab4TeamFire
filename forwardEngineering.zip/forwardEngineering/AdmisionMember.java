import java.util.Vector;

public class AdmisionMember {

  public String nume;

    public Vector  myAdmisionComitee;

  public void setNume() {
  }

  public String getNume() {
  return null;
  }

}