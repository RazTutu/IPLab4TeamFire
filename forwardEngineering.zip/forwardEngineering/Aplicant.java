import java.util.Vector;

public class Aplicant {

  public String nume;

  public Double medie;

    public Vector  myAplicatie;

  public void setNume() {
  }

  private String getNume() {
  return null;
  }

  public void setMedie() {
  }

  public double getMedie() {
  return 0.0;
  }

}