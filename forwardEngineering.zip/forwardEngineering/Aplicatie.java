import java.util.Vector;

public class Aplicatie {

  public Specializare NumeSpecializare;

    public Vector  myAplicant;
    public Vector  myApplicationDatabase;
    public Vector  myAdmisionComitee;

}