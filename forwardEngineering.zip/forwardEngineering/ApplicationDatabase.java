import java.util.Vector;

public class ApplicationDatabase {

  public int id;

  public String nume;

  public String medie;

    public Vector  myAplicatie;

}