public class Specializare {

  private String OptimizareComputationala;

  public String SistemeDistribuite;

  private String SecuritateaInformatiei;

  public String InginerieSoftware;

}